# entity-learn

Cited memory for agents: **immutable observations, scoped recall, and explicit refresh**.

A reference names a subject. An observation preserves what was obtained, when, and from whom. Retrieval selects evidence; it never runs stored commands. Tardigrade owns the agent loop, retries, and tool-result history.

## Install and verify

Node 22.13+ for the library/CLI. Bun 1.4+ for Tardigrade and the tests.

```sh
npm ci
npm test                 # build, typecheck, Node CLI tests, Tardigrade host tests
node bin/entity-learn.mjs --help
```

This checkout is version 0.2.0; it has not been published by these changes. For use from another local project, build and `npm pack`, then install that tarball. The core has no runtime npm dependencies. The Tardigrade integration uses optional peers `tardie@0.5.x` and `effect@4.0.0-rc.110`.

## Remember, correct, recall

```sh
entity-learn remember '{
  "subject":"project/video/master-clock",
  "title":"Master clock",
  "type":"decision",
  "payload":{"take":"B","durationSeconds":176.72}
}' --key decision-1

entity-learn query --search 'master clock'
entity-learn history project/video/master-clock
entity-learn get obs_<digest-from-the-write>
```

A correction supplies `supersedes` with the exact current observation ID. A stale writer gets `head_conflict`, not last-writer-wins. Old observation IDs still resolve to their original bytes.

```sh
entity-learn remember '{
  "subject":"project/video/master-clock",
  "title":"Master clock",
  "type":"decision",
  "payload":{"take":"C"},
  "supersedes":"obs_<current-digest>"
}' --key decision-2

entity-learn query --subject project/video/master-clock --as-of 2026-09-05T12:00:00Z
```

Use `--db` and `--scope` consistently. Defaults are `~/.agent-org/memory.sqlite` and `local`; `ENTITY_MEMORY_DB` and `ENTITY_MEMORY_SCOPE` can override them. CLI scope selection is a trusted operator feature, **not authentication**.

Every result includes its observation ID, producer, observation/recording times, validity, and freshness. `not-applicable` means no freshness lifetime was asserted—not “eternally true.” `asOf` reconstructs recorded history; it cannot recover a source state that was never observed.

## Tardigrade

Mount a native code-mode package beside your existing packages:

```ts
import { codeModeFor } from "tardie";
import { Memory } from "entity-learn";
import { memoryPackage } from "entity-learn/tardigrade";

const memory = memoryPackage({
  open: () => new Memory({
    path: ".tardigrade/memory.sqlite",
    scope: "project:my-project", // trusted host binding, never a model argument
  }),
  writable: true,
});

const code = codeModeFor({ packages: [memory] });
// Add `code` to actorOf(agentRuntime(), [...components]).
```

The actor can call:

```js
const found = await memory.recall({ search: "master clock", maxBytes: 8000 });
return found;
```

Tools: `recall`, `get`, `history`, `sources`; opt-in `remember`, `forget`; separately granted `refresh`. Source registration and approval are never model tools. All package writes are attributed to the agent, not silently promoted to user-stated facts.

Writes use Tardigrade's actor/thread address and recorded package-call ID as the idempotency key. If memory commits and the host crashes before recording the tool return, recovery gets the original receipt. Different threads can share a project scope without sharing a conversation log.

See [the complete actor](examples/tardigrade/actor.ts) and [integration guide](docs/tardigrade.md). This integration is tested against the installed **0.5.0** API (`defineActor`, `actorOf`, `codeModeFor`), not the newer `actor`/`codeMode([...])` examples in some skill versions.

### Logs compose with entities too

`tardigradeLogSource()` adapts an authorized, paged Tardigrade log reader into episode entities:

```text
summary → cited log episode → related issue or decision
```

Events retain stable actor/thread/sequence references and original-event digests. The host chooses content and relationship links; defaults are metadata-only. Partial windows expose their cursor and coverage. Refreshing a log **reads events; it never replays their tool calls**. Those episodes then use the same recall, citation, and graph APIs as every other entity. [Log adapter setup](docs/tardigrade.md#logs-are-composable-tool-sources).

## Live sources: separate registration, approval, and execution

```sh
entity-learn learn --file ./issues.json --id issues \
  --namespace github/owner/repo --type issue --id-field number --ttl 300

entity-learn approve issues --revision <revision-returned-by-learn>
entity-learn refresh issues --key observation-1
entity-learn query --search '76'
```

`learn` registers a **disabled** source and does not read its payload. `refresh` is the only source-executing operation. A file may be JSON, JSONL, or plain text/Markdown (`--format text`). Text is one bounded document, not automatically asserted facts. Configured identity/title/status fields fail on schema drift. No positional array identities are invented.

Source results become subjects such as `github/owner/repo/issue/76`. Empty successful refreshes remove current entities from that source without deleting pinned history. Failures retain prior observations with explicit stale/error labels; three consecutive failures disable the source until reapproved. Changing a recipe revokes its prior approval.

For APIs or native Contract calls, register an `adapter` source through the library and mount a host-owned `SourceRunner` in `MemoryOptions.adapters`. Keep authentication and execution policy in the host. Adapters must be read-only, honor the abort signal, bound network bodies, and never return secrets. A registered name is not an execution grant. The package contains no shell executor or general HTTP proxy.

## Evidence graph and retrieval budgets

- `supports`: exact historical citations. A newer source revision does not rewrite what an old citation said.
- `dependsOn`: exact inputs whose **current heads** matter. A changed, expired, or failed input makes the derivation stale, transitively.
- `links`: explicitly labeled subject relationships. Traversal does not turn a relationship into evidence or authority.

Evidence references must already exist in the same scope, so the immutable evidence graph cannot contain forward edges or cycles. Relationship cycles are allowed and deduplicated during traversal.

```sh
entity-learn query --search 'Take B' --depth 1 --max-nodes 16 --max-bytes 8000
```

Recall filters the scope before BM25 scoring and graph expansion. Numeric identifiers, booleans, and Unicode are indexed in the lexical corpus. `--subject` is exact lookup. No embeddings, graph server, or LLM extraction service is required.

Defaults: 2,000 candidates, 10 root matches, 32 visited result nodes, depth 0, and a 12,000-byte compact JSON response. Payloads are limited to 64 KiB. Byte/node/candidate/result limits report `coverage: "partial"` and reasons instead of silently implying completeness. Coverage concerns **recorded observations in this scope**, never the whole external world. `get` is the explicit full-observation escape hatch when recall omits an oversized item.

## Contract interoperability

```sh
entity-learn import-contract --file ./exported-settlement.json
```

Supported input: an exported `neuron_skill_node_settled` row, or a `neuron_transaction` containing those rows, with `evidence_payload` and `evidence_digest`. The importer checks the existing Contract SHA-256 compact-JSON digest, preserves a settlement-specific provenance reference, and is replay-safe. Two different settlements with equal payloads retain separate observation identities.

**This is a read-only evidence import, not native Contract admission.** A matching digest proves byte integrity, not signature authenticity, factual correctness, current validity, or authorization. Use a host-authorized export. Imported evidence is a pinned local copy; upstream revocations are not automatically polled. Native execution, signing, settlement, and policy remain in `commons/contract`. No Contract ledger is written by this package. [Architecture and limits](docs/architecture.md).

## Storage and forgetting

One SQLite transaction commits content-addressed payload artifacts, the append-only hash-chained journal, and disposable read projections. Equal payloads occupy one artifact row. Receipt hashes bind metadata, payload digest, and exact evidence references. Reads verify artifact and observation digests. `rebuild` verifies the journal chain and rebuilds heads, sources, and observation metadata without executing sources.

```sh
entity-learn rebuild
entity-learn forget project/video/master-clock --expected obs_<current-digest>
```

`forget` suppresses all versions of a subject and claims that depend on/cite it. Refresh or replay cannot restore that subject. **It is not physical erasure:** artifacts, journal events, Tardigrade tool-return history, already-loaded context, independent copies, and backups may still contain the data. There is deliberately no automatic destructive GC or erasure claim.

The database is plaintext with mode 0600; scopes are application boundaries, not encryption or an OS sandbox. Protect the database and its WAL files. Secret-pattern rejection is defense in depth, not comprehensive DLP. Hashes are not signatures, and an attacker able to rewrite the whole database can replace the chain. Do not mount this behind untrusted unrestricted JavaScript and call that tenant isolation.

## Migrating from 0.1

```sh
entity-learn import-v1 --file ~/.agent-org/pointers.json
```

Migration is explicit and imports only cached data, as **stale historical observations**. Commands are discarded, never replayed or retained. Uncached pointers are skipped. The old file is untouched. Admission is per observation; on failure, fix the offending input and rerun the same export to resume idempotently.

Breaking changes: `query` returns a coverage/freshness envelope, IDs are namespaced, corrections are conditional, and shell `learn`, implicit resolve, automatic bootstrap replay, and the old HUD are no longer public APIs. The old paper and benchmark artifacts describe 0.1; their numbers are not claims about 0.2.

## License

MIT.
