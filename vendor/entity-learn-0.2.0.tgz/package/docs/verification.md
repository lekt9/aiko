# Verification of 0.2 implementation

## Checks

- `npm run check`: builds library/CLI, typechecks library + tests + example, runs 41 passing tests.
- `tdg build examples/tardigrade/actor.ts --out /tmp/entity-learn-memory-actor-final --json`: builds `memory-assistant`.
- `npm pack --dry-run --ignore-scripts --json` after the build: confirms public library declarations, CLI, example, and docs are packaged; no database, HUD server, node_modules, or personal files.
- Offline installation of the built tarball in an empty temporary project: core import, remember, pinned get, recall, and CLI help pass without installing Tardigrade/Effect.
- `npm audit --omit=dev`: zero reported vulnerabilities.
- `git diff --check`: clean.

Runtime used: Node 24.18.1, Bun 1.4.0, Tardie 0.5.0, Effect 4.0.0-rc.110. Node 22.13 is the declared minimum, not an independently tested runtime in this verification.

## What the tests establish

- Numeric IDs, Unicode, namespace isolation, and stable unkeyed-array identities.
- Scoped exact reads, scoped ranking/version reporting, and scope-safe evidence/relationships.
- Conditional corrections, multi-process writes, idempotent requests, and rejection of changed retry input.
- Deduplicated payload artifacts, pinned historical bytes, journal/projection repair, and corrupt-artifact rejection.
- Explicit source approval, no execution during recall/pinned reads/rebuild, source-race protection, expiry, removal, failure labeling, quarantine, and deadlines.
- Bounded regular-file reads, including rejection of FIFOs before opening can block.
- Transitive dependency freshness, support citations, graph/byte/candidate bounds, and suppression without claiming physical erasure.
- Cache-only legacy migration without executing/persisting legacy commands, including keyed-map identities.
- Contract export digest checking and distinct receipts for different settlements sharing evidence bytes.
- Pure Tardigrade package derivation; host-bound grants; rejection of model-controlled scope/provenance.
- Actual code-mode dispatch through durable local Tardigrade hosts, cross-thread recall, and crash recovery after memory commits but before acknowledgement.
- Import of an actual fixture host's public log into episode entities, then relationship traversal to that thread's remembered decision.
- Bounded log windows, source coverage/cursors, metadata-only defaults, host-selected content, explicit relationship hints, and credential rejection.

## Review findings addressed

The review caught and fixed lost upstream adapter citations, non-deduplicated payload storage, unscoped retrieval version counts, log-window coverage loss, unkeyed identities changing with array cardinality, FIFO opening that could outlive a deadline, and inconsistent first/replayed refresh-result envelopes. The old shell-interpolating HUD entrypoint is disabled and its obsolete renderer removed.

## Limits of the evidence

This is local deterministic integration verification, not a production security audit or an answer-quality benchmark. Tests do not require model credentials or paid inference. No personal pointer store, personal Tardigrade log, live production command, or Contract ledger was read or replayed. No deployment, publish, or commit was performed.

The log adapter's remote transport is supplied by the host; no live authenticated Tardigrade HTTP service was connected. Contract interoperability was checked against local wire-shape/serializer source and synthetic exported settlements, not a live native admission flow. Upstream authorization, signatures, revocation, network cancellation, and tenant/process isolation remain host responsibilities.

There is no before/after token-cost claim, large-corpus performance claim, distributed-host verification, physical-erasure claim, or full Contract governance integration. See [architecture.md](architecture.md) for the complete boundaries.
