# Architecture and limits

## Three things, not one recursive pointer interpreter

1. **Subject/reference:** a stable, scoped name such as `github/owner/repo/issue/76` or `tardigrade/researcher/run-1/event/12`.
2. **Observation:** an immutable receipt binding a subject, exact payload digest, producer, times, correction parent, and evidence references.
3. **Projection:** a disposable current-head/search view, with explicit scope, time, graph, and byte budgets.

An approved source recipe is how the host obtains a **new** observation. A pinned observation is never resolved by running that recipe. The source batch identity and any upstream evidence reference are preserved separately.

```text
approved read-only tool / file / Tardigrade log window / Contract export
                              |
                      explicit observation
                              v
                   content-addressed artifact
                              ^
                              | payloadDigest
                        observation receipt
                        /        |        \
                supersedes   supports    dependsOn
                              |
                 scoped lexical + graph projection
```

Tardigrade log entries compose at the same layer as other tool entities. A decision can cite an episode; an episode can link to an issue. These edges do not make a recorded command executable or a model-produced statement authoritative.

## Durability and addressing

`Journal` uses SQLite WAL, `synchronous=FULL`, and a five-second busy timeout. Each write holds `BEGIN IMMEDIATE` through artifact insertion, journal append, and projection updates. A refresh does external I/O **outside** the transaction, then conditionally publishes only if the source revision/health/batch is unchanged.

Canonical tables:

- `artifacts(digest, body)`: canonical JSON payload bytes, inserted once per digest.
- `journal`: append-only scoped events, request identities, previous hash, and event hash.

Disposable tables:

- `observations`: immutable receipt metadata, with payload digest rather than copied payload bytes.
- `heads`: current receipt and suppression flag per scoped subject.
- `sources`: registered recipe, approval, latest batch, failure state, and source coverage.

Payload, observation, request, source, and journal hashes use distinct SHA-256 domains. Observation hashes exclude the inline API payload and bind its digest instead; they also bind scope, producer, times, and exact evidence IDs. Equal payloads deduplicate even when their receipts or scopes differ.

`get` and retrieval hydrate payloads from artifacts and verify their digests and observation identity. Missing/corrupt artifacts fail closed. `rebuild` checks sequence continuity, the hash chain, artifacts, and receipts, then regenerates projections in one transaction; failure rolls back. Rebuilding is explicit and never calls a source. Normal reads do not verify the entire journal on every request.

Hash integrity assumes a trusted local store. There is no externally anchored/signed root, encrypted tenant storage, destructive GC, or protection against an attacker rewriting the whole database and its projections. Back up journal **and** artifacts together using SQLite-safe backup/snapshot procedures, not a live copy of only the main file while ignoring its WAL.

## Idempotency and source races

A unique `(scope, request_key)` binds the request's canonical digest to its first committed outcome. Changed input with the same key is refused. Corrections and forgetting require the exact current observation ID.

For Tardigrade, the write key derives from `Self`, the recorded package `callId`, and the operation. This bridges a memory commit and a later Tardigrade tool-return commit. It does not guarantee exactly-once source execution: a crash after a read but before memory commit can repeat that read. Thus adapters must not have business side effects.

Each successful refresh is one atomic batch. The previous batch remains historically addressable. An entity absent from the new batch is no longer current. A changed source recipe starts disabled. Failures preserve prior data but label it stale/error; three consecutive failures quarantine the source. An old in-flight refresh cannot overwrite a newer refresh or newly changed approval.

Adapter implementation and authentication are host policy. Version adapter registrations when implementation meaning changes. The Tardigrade log helper binds actor, thread, window, and an explicit custom projection policy version into its locator; it rejects mismatched registrations.

## Temporal and evidence semantics

- `observedAt`: when the input was observed; cannot be in the future at admission.
- `recordedAt`: when this store admitted it.
- `expiresAt`: optional freshness boundary; zero TTL is immediately stale.
- `validFrom` / `validTo`: separately asserted validity interval.
- `asOf`: transaction-time selection over what was actually recorded, evaluated at that time.

A pinned historical payload stays exact even when its subject has changed. `supports` preserves historical citations. `dependsOn` additionally requires current inputs and checks their freshness transitively. Relationships use subject names and follow the current permitted target; they do not certify evidence.

Evidence edges can only target already committed, same-scope observations. Forward references and cycles cannot be admitted. Disclosure validates the support/dependency closure, capped at 256 observations, before returning a claim. Writes whose combined closure exceeds that bound are rejected. Relationship traversal is separately bounded and deduplicates cycles.

Suppression is checked against **present** forget state even for time-travel reads. Forget hides all revisions and claims citing/depending on them; it does not resurrect an older head. This intentionally does not erase canonical bytes or independent copies. A fact manually rephrased without a citation is not automatically recognized as a derivative.

## Retrieval and bounded source coverage

Scope filtering precedes lexical scoring, exact reads, and relationship traversal. Scope is host-bound in the Tardigrade package. CLI and direct library callers are trusted operators and can select a scope; sharing their process/files with untrusted code is not tenant isolation.

BM25 scans the bounded permitted current corpus, including numeric identifiers, booleans, Unicode, and explicit relationship labels/subjects. No FTS index, embedding model, ANN database, daemon, or recursive source executor is implemented. Large-corpus throughput and answer quality have not been benchmarked for 0.2.

Defaults are 2,000 candidates, 10 root matches, 32 result nodes, depth 0, and 12,000 bytes of compact JSON. Maximum expansion depth is 4. A 512-byte envelope reserve keeps whole receipts within the response budget; oversized receipts are omitted, never silently shortened. Use `get` for a selected full observation. A fixed point makes the returned `bytes` count include its own serialized value.

Coverage reasons include candidate/result/node/byte limits, inaccessible evidence, excluded stale results, unobserved/failed sources, and partial source windows. Source coverage can carry a pagination cursor. A Tardigrade window with a nonzero `after` explicitly excludes a prefix; the engine does not infer that other windows collectively prove whole-thread completeness.

Limits bound admitted data, not arbitrary host behavior. External adapters must enforce network response limits and cancellation themselves. A non-cooperative adapter can keep running after the memory deadline, but its late result is not published. Local file sources reject non-regular files and oversized reads. Maximum payload is 64 KiB and maximum atomic event is 1 MiB.

## Interoperability, not duplicate governance

Contract import verifies the existing digest of an exported compact-JSON evidence payload and retains a settlement-specific reference. It does not authenticate the exporter, interpret a matching digest as truth, admit effects, read a personal ledger, execute a native neuron, or write Contract state. Upstream revocation is not automatically mirrored. Only the documented settlement/transaction export shapes are supported.

Tardigrade owns threads, schedules, retries, and event retention. The code-mode memory package opens resources only inside effects. Its log-source helper accepts the public `{ seq, event }` read shape; no log tables or Tardigrade internal reducers are accessed. Hosts can compose the same memory package with their existing public log tools.

The implementation is local-first Node/Bun SQLite. It is not a distributed store, cloud D1 adapter, automatic personal-memory importer, or comprehensive security boundary around Tardie 0.5's in-process JavaScript sandbox.
