# Tardigrade integration

## Version and boundary

Tested: `tardie@0.5.0`, `effect@4.0.0-rc.110`, Bun 1.4.0. The installed Tardigrade skill mentions a newer CLI/API; use the installed version's `tdg --help` and this example rather than mixing generations.

This is a **code-mode package**, not another agent loop or a replacement Tardigrade store. Tardigrade owns threads and their event logs. Entity-learn owns a shared memory journal and content-addressed payloads. An idempotency key bridges the two commit boundaries; there is no distributed transaction and no exactly-once external-read claim.

## Mount

Build/package this repository first. In the actor project:

```sh
bun add /absolute/path/to/entity-learn-0.2.0.tgz tardie@0.5.0 effect@4.0.0-rc.110
```

Copy [actor.ts](../examples/tardigrade/actor.ts), or add the package to an existing `codeModeFor({ packages: [...] })`. Preserve the existing actor's stable name and other components.

```ts
import { Memory } from "entity-learn";
import { memoryPackage } from "entity-learn/tardigrade";

const sharedMemory = memoryPackage({
  open: () => new Memory({
    path: "/absolute/persistent/project-memory.sqlite",
    scope: "tenant:example/project:research",
  }),
  writable: true,
  refreshSources: ["issues"], // optional and independent of write access
});
```

`open` must return a new handle; the package closes it after the effect. No file/clock/source reads happen during component derivation. Keep the database on persistent local disk and outside a model-writable workspace when isolation matters. Multiple threads/processes on the same host can use it; do not put SQLite WAL on a network filesystem or assume a local file replicates across fleet workers.

Bind scope and refresh grants from trusted host configuration or authenticated tenant routing. Do not interpolate a model-supplied scope/path. The CLI's `--scope` is an operator convenience, not a tenant authenticator.

## Call from code mode

```js
const result = await memory.recall({ search: "master clock", maxBytes: 8000 });
return result;
```

```js
const saved = await memory.remember({
  subject: "project/video/master-clock",
  type: "decision",
  title: "Master clock",
  payload: { take: "B" },
  supports: [], // include exact existing observation IDs when this is derived
});
return saved;
```

For a correction, recall the current record and supply its `observation.id` as `supersedes`. A competing write returns `head_conflict`; reread and reconsider instead of blindly retrying with the new head. `remember` records an **agent claim**. It does not certify that the user said the text, nor that the model's extraction is true.

```js
const prior = await memory.get({ observation: "obs_<digest>" });
const history = await memory.history({ subject: "project/video/master-clock", limit: 10 });
return { prior, history };
```

A current-state request may use `memory.refresh({ source: "issues" })` only if that source appears in the host's `refreshSources` grant and its exact recipe is approved. `sources({})` reports health without exposing host file paths or credentials. There is no registration, shell, credential, or arbitrary HTTP tool.

## Logs are composable tool sources

A Tardigrade log is itself evidence produced by a read-only tool. Import a bounded window as episode entities, then compose those episodes with existing issues, decisions, and summaries:

```text
summary --cites exact observation--> log episode --mentions--> issue
```

`links` follow subjects; `supports` pins evidence receipts. A link or recorded tool call is never an execution grant.

```ts
import { tardigradeLogSource } from "entity-learn/tardigrade";

const logs = tardigradeLogSource({
  id: "research-run-1",
  actor: "researcher",
  thread: "run-1",
  maxEvents: 50,
  // Your existing authorized host-side log reader; not a model-provided function.
  read: readApprovedLogPage,
  project: row => ({
    type: row.event.type,
    // Example selected content; apply your own redaction policy here.
    text: row.event.type === "MessageReceived" ? String(row.event.text ?? "") : "",
  }),
  relate: row => row.event.type === "PackageCalled"
    ? [{ subject: "project/video/master-clock", relation: "mentions" }]
    : [], // Example for a run known to concern that entity, not a universal inference.
  policyVersion: "project-log-selection-v1",
});

const open = () => new Memory({
  path: "/absolute/persistent/project-memory.sqlite",
  scope: "project:video",
  adapters: { [logs.source.locator]: logs.run },
});

// Trusted setup, outside actor derivation. Approval is an operator decision.
const memory = open();
try {
  const registered = memory.registerSource(logs.source, "register-run-1");
  memory.approveSource(registered.id, registered.revision, true, "approve-run-1");
} finally { memory.close(); }

const memoryTools = memoryPackage({ open, refreshSources: [logs.source.id], writable: true });
```

Then normal code-mode composition works:

```js
const refreshed = await memory.refresh({ source: "research-run-1" });
if (refreshed.error) return refreshed;
return await memory.recall({ search: "master clock", depth: 1, maxBytes: 8000 });
```

`readApprovedLogPage` is a **host implementation you supply**, with arguments `{ actor, thread, after, limit, signal, maxBytes }` and result `ReadonlyArray<{ seq, event }>`. Use the public Tardie 0.5 `makeClient(...).events(thread, { after, limit })` API, or an already-mounted read-only log tool—not its private SQLite tables. Bind credentials and routing in that implementation. The public client supports a custom `fetch`; use that transport to enforce the passed cancellation/body budget. The helper bounds admission but cannot constrain a reader that ignores its contract.

Rows must have contiguous, unfiltered 1-based sequence numbers. The helper reads at most `maxEvents + 1` rows to detect a capped page. It retains stable actor/thread/sequence references and a canonical digest of each original event. Content defaults to **metadata only**; custom content/link selection requires a `policyVersion`, which changes the registered recipe when updated.

Event and byte caps produce partial source coverage, a `nextAfter` cursor, and recall's `source_partial` reason. The host can register the next non-overlapping window using that cursor. It is not an automatic whole-log crawler. Keep a stable actor/thread identity for an append-only log; use a new identity when replacing a log rather than silently reusing its sequence numbers.

A projected log receipt preserves the selected JSON, not necessarily the entire original event. Its event digest is not a signature or proof that a tool succeeded. Don't recursively select complete `memory.recall`/`remember` returns: that copies earlier memory into later logs indefinitely. Prefer bounded selected content and explicit citations.

## Replay and correction behavior

The write key binds the actor address, thread, package-call ID, and operation. It does **not** use a fresh UUID or wall clock inside the retry.

| Interruption | Recovery |
| --- | --- |
| Before memory commits | The operation may run again |
| After memory commits, before Tardigrade records the return | The original memory receipt is returned |
| Same call ID with changed arguments | `idempotency_conflict` |
| Evidence forgotten before write replay | Payload disclosure is refused; the subject is not restored |
| Source read completed but process died before memory commit | The read may repeat; adapters must be read-only |
| Source revision changed during a read | `source_changed`; the stale result is not published |

Failures are structured `{ error: { code, message } }` values, not swallowed success. `refresh` returns `{ observations, error }`; inspect `error`. A retry of the same committed failed refresh returns that failure. Use a **new package call** for a deliberate new observation attempt.

## Run the example

From this repository after `npm run build`:

```sh
tdg build examples/tardigrade/actor.ts
# When you want to run an actual model-backed actor:
tdg push examples/tardigrade/actor.ts --target local
ENTITY_MEMORY_DB=/absolute/path/to/memory.sqlite \
ENTITY_MEMORY_SCOPE=project:memory-assistant tdg dev
```

In another terminal, use the same server and installed CLI:

```sh
tdg run 'Remember that our master clock is Take B. Then retrieve it.' --actor memory-assistant
```

`tdg run` prints the Voyager trace URL. Model credentials are configured through Tardigrade, not stored in memory. The implementation verification uses a deterministic model seam and real durable Bun hosts; no paid model call or deployment is required for the tests.

For CLI access to an example actor's memories, use the same absolute `--db` and `--scope`. The standalone CLI's defaults intentionally do not guess a Tardigrade project's store.

## Safety and portability

- `memoryPackage({ open })` defaults to read-only methods. `writable: true` adds remember/forget. `refreshSources` separately adds refresh.
- Retrieved payloads are untrusted tool data. Never concatenate them into privileged system instructions or use them to change grants.
- Package scope checks do not sandbox arbitrary JavaScript. Tardie 0.5's default JavaScript sandbox is an in-process async function. Use an appropriate isolated host/sandbox and file permissions for adversarial code or tenants; this package alone cannot secure that runtime.
- Forgetting affects future memory retrieval. Tardigrade's existing `ToolReturned` records and already-loaded context are separate retained copies. Erasure requires the host's own retention controls.
- This adapter targets Node/Bun SQLite hosts. It is not a Cloudflare Durable Object/D1 backend and has not been validated on Celld fleets.
- No Tardigrade internals are queried or written. The integration uses public `Package`, `Self`, `codeModeFor`, and `createBunHost` surfaces.

## Verification

`npm test` exercises pure derivation, model-argument rejection, host grants, Tardigrade call IDs, real code-mode dispatch, separate-thread recall, and recovery after a simulated crash between memory commit and acknowledgement. The complete actor also builds with `tdg build`.

This repository had no pre-existing Tardigrade actor, so no before/after model-token, dollar-cost, or answer-quality comparison is claimed. Those require workload-specific evaluations and real provider runs.
